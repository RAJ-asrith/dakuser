const SCIENTIST_API = 'https://687b3ad3b4bc7cfbda850ef2.mockapi.io/scientist';
const DAK_API = 'https://687b3ad3b4bc7cfbda850ef2.mockapi.io/dak';

export const fetchScientists = async () => {
  const res = await fetch(SCIENTIST_API);
  return res.json();
};

export const fetchDaks = async () => {
  const res = await fetch(DAK_API);
  return res.json();
};
