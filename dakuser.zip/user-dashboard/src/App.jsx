import React from "react";
import UserDashboard from "./components/UserDashboard";
import "./index.css";

function App() {
  // Replace "1" with the current/logged-in user ID
  const userId = "1";
  return (
    <div className="app">
      <UserDashboard currentUserId={userId} />
    </div>
  );
}
export default App;
