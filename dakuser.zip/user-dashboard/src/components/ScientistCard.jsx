// src/components/ScientistCard.jsx
import React from "react";

export default function ScientistCard({ scientist, daks }) {
  return (
    <div className="scientist-card">
      <h3>
        {scientist.name} <span className="designation">({scientist.designation})</span>
      </h3>
      {daks.length === 0 ? (
        <p className="no-dak">No DAKs assigned.</p>
      ) : (
        <ul className="dak-list">
          {daks.map((dak) => (
            <li key={dak.id} className="dak-item">
              <strong>DAK No:</strong> {dak.DAK_NO} | <strong>Status:</strong> {dak.STATUS}
              <br />
              <strong>Remarks:</strong> {dak.REMARKS}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
