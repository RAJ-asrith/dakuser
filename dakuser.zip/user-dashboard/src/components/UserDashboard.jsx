import React, { useEffect, useState } from "react";
import { fetchScientists, fetchDaks } from "../api/api";
import "./UserDashboard.css";

function userHasRoleInDak(user, dak, role) {
  if (role === "responsible") return dak.RESP_OFFICER === user.name;
  if (role === "coordinator") return dak.CO_ORD === user.name;
  if (role === "monitoring")
    return Array.isArray(dak.MONITORING_OFFICERS) && dak.MONITORING_OFFICERS.includes(user.name);
  return false;
}

const ROLE_OPTIONS = [
  { value: "responsible", label: "Responsible Officer" },
  { value: "coordinator", label: "Coordinator" },
  { value: "monitoring", label: "Monitoring Officer" }
];

export default function UserDashboard({ currentUserId }) {
  const [scientist, setScientist] = useState(null);
  const [myDaks, setMyDaks] = useState([]);
  const [roleFilter, setRoleFilter] = useState("responsible");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [editingDak, setEditingDak] = useState(null);
  const [form, setForm] = useState({
    letter_no: "",
    letter_date: "",
    mode_of_reply: "",
    remarks: "",
    user_attachment: ""
  });

  // === NEW STATE FOR SEARCH AND SORT ===
  const [searchQuery, setSearchQuery] = useState("");
  const [sortConfig, setSortConfig] = useState({ key: null, direction: "asc" });

  useEffect(() => {
    setLoading(true);
    setError("");
    async function load() {
      try {
        const scientistList = await fetchScientists();
        const user = scientistList.find(s => s.id === currentUserId);
        if (!user) throw new Error("User not found!");
        setScientist(user);

        const daks = await fetchDaks();
        const relatedDaks = daks.filter(
          dak =>
            dak.RESP_OFFICER === user.name ||
            dak.CO_ORD === user.name ||
            (Array.isArray(dak.MONITORING_OFFICERS) &&
              dak.MONITORING_OFFICERS.includes(user.name))
        );
        setMyDaks(relatedDaks);
      } catch (e) {
        setError(e.message || "Failed to load data.");
      }
      setLoading(false);
    }
    load();
  }, [currentUserId]);

  if (loading)
    return (
      <div className="loading-container">
        <div className="loading-spinner">
          <div className="loading-ring"></div>
          <div className="loading-ring"></div>
          <div className="loading-ring"></div>
        </div>
        <p className="loading-text">Loading dashboard...</p>
      </div>
    );

  if (error)
    return (
      <div className="error-container">
        <div className="error-icon">⚠️</div>
        <div className="error-text">{error}</div>
      </div>
    );

  if (!scientist) return null;

  // This is your original role filter
  let filteredDaks = myDaks.filter(dak => userHasRoleInDak(scientist, dak, roleFilter));

  // === SEARCH FILTER ===
  let tableDaks = filteredDaks;
  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase();
    tableDaks = tableDaks.filter(dak =>
      (dak.DAK_NO && dak.DAK_NO.toLowerCase().includes(q)) ||
      (dak.RESP_OFFICER && dak.RESP_OFFICER.toLowerCase().includes(q)) ||
      (dak.STATUS && dak.STATUS.toLowerCase().includes(q)) ||
      (dak.NOMENCLATURE && dak.NOMENCLATURE.toLowerCase().includes(q)) ||
      (dak.DIRECTOR_REMARKS && dak.DIRECTOR_REMARKS.toLowerCase().includes(q)) ||
      (dak.CO_ORD && dak.CO_ORD.toLowerCase().includes(q))
    );
  }

  // === SORTING ===
  if (sortConfig.key) {
    tableDaks = [...tableDaks].sort((a, b) => {
      let v1 = (a[sortConfig.key] || "").toString().toLowerCase();
      let v2 = (b[sortConfig.key] || "").toString().toLowerCase();
      if (v1 < v2) return sortConfig.direction === "asc" ? -1 : 1;
      if (v1 > v2) return sortConfig.direction === "asc" ? 1 : -1;
      return 0;
    });
  }

  // === HANDLE SORT FUNCTION ===
  function handleSort(columnKey) {
    setSortConfig(prev => {
      if (prev.key === columnKey) {
        return { key: columnKey, direction: prev.direction === "asc" ? "desc" : "asc" };
      }
      return { key: columnKey, direction: "asc" };
    });
  }

  function handleUpdateClick(dak) {
    let todayStr = new Date().toISOString().substring(0, 10);
    let letterDate = todayStr;
    if (
      dak.ION_LETTER_DATE &&
      !isNaN(Number(dak.ION_LETTER_DATE)) &&
      Number(dak.ION_LETTER_DATE) > 0
    ) {
      letterDate = new Date(Number(dak.ION_LETTER_DATE) * 1000).toISOString().substring(0, 10);
    }

    setEditingDak(dak);
    setForm({
      letter_no: dak.ION_LETTER_NO || "",
      letter_date: letterDate,
      mode_of_reply: dak.MODE_OF_REPLY || "",
      remarks: dak.REMARKS || "",
      user_attachment: ""
    });

    setTimeout(() => {
      const el = document.querySelector(
        "#fullscreen-update-form input, #fullscreen-update-form select, #fullscreen-update-form textarea"
      );
      if (el) el.focus();
    }, 100);
  }

  function handleFormChange(e) {
    const { name, value, type, files } = e.target;
    setForm(f => ({
      ...f,
      [name]: type === "file" ? files[0] : value
    }));
  }

  function handleClear(e) {
    if (e) e.preventDefault();
    setEditingDak(null);
    setForm({
      letter_no: "",
      letter_date: "",
      mode_of_reply: "",
      remarks: "",
      user_attachment: ""
    });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const dataToSend = {
      ION_LETTER_NO: form.letter_no,
      ION_LETTER_DATE: Math.floor(new Date(form.letter_date).getTime() / 1000),
      MODE_OF_REPLY: form.mode_of_reply,
      REMARKS: form.remarks,
      STATUS: "Completed"
    };
    try {
      const response = await fetch(
        `https://687b3ad3b4bc7cfbda850ef2.mockapi.io/dak/${editingDak.id}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(dataToSend)
        }
      );
      if (!response.ok) throw new Error("Failed to update DAK");

      alert("DAK updated successfully!");
      setEditingDak(null);
      setLoading(true);

      // Reload all fetched DAKs in user scope
      const daks = await fetchDaks();
      const user = scientist;
      const relatedDaks = daks.filter(
        dak =>
          dak.RESP_OFFICER === user.name ||
          dak.CO_ORD === user.name ||
          (Array.isArray(dak.MONITORING_OFFICERS) &&
            dak.MONITORING_OFFICERS.includes(user.name))
      );
      setMyDaks(relatedDaks);
      setLoading(false);
    } catch (err) {
      alert("Update failed: " + err.message);
    }
  }

  return (
    <div className="dashboard-container">
      <div className="dashboard-background"></div>
      <section className="dashboard-header">
        <div className="welcome-card">
          <div className="avatar-container">
            <div className="avatar">
              {scientist.name.charAt(0).toUpperCase()}
            </div>
            <div className="status-indicator"></div>
          </div>
          <div className="user-info">
            <h2 className="welcome-title">
              Welcome, {scientist.name}
            </h2>
            <p className="designation">{scientist.designation}</p>
          </div>
        </div>
      </section>
      <section className="filter-section">
        <div className="filter-card">
          <label className="filter-label">View as:</label>
          <div className="select-wrapper">
            <select
              className="role-select"
              value={roleFilter}
              onChange={e => setRoleFilter(e.target.value)}
            >
              {ROLE_OPTIONS.map(opt => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
            <div className="select-arrow">
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M7 10l5 5 5-5z" />
              </svg>
            </div>
          </div>
        </div>
      </section>
      <section className="content-section">
        <h3 className="section-title">
          Your Associated DAKs as{" "}
          <span className="role-badge">
            {ROLE_OPTIONS.find(o => o.value === roleFilter).label}
          </span>
        </h3>

        {/* --- Always show the search bar here (even if no results) --- */}
        <div style={{ display: "flex", justifyContent: "flex-end", alignItems: "center", padding: "8px 0" }}>
          <input
            type="text"
            placeholder="Search..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            style={{
              padding: "6px 12px",
              border: "1px solid #ccc",
              borderRadius: 4,
              minWidth: 200
            }}
          />
        </div>

        {tableDaks.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">📋</div>
            <p className="empty-message">
              No DAKs assigned to you as{" "}
              <strong>
                {ROLE_OPTIONS.find(o => o.value === roleFilter).label}
              </strong>
              {searchQuery ? " matching your search." : "."}
            </p>
          </div>
        ) : (
          <div className="table-container">
            <div className="table-wrapper">
              <table className="modern-table">
                <thead>
                  <tr>
                    <th
                      onClick={() => handleSort("DAK_NO")}
                      style={{ cursor: "pointer" }}>
                      DAK No {sortConfig.key === "DAK_NO" && (sortConfig.direction === "asc" ? "▲" : "▼")}
                    </th>
                    {roleFilter === "responsible" && (
                      <th
                        onClick={() => handleSort("RESP_OFFICER")}
                        style={{ cursor: "pointer" }}>
                        Responsible Officer {sortConfig.key === "RESP_OFFICER" && (sortConfig.direction === "asc" ? "▲" : "▼")}
                      </th>
                    )}
                    <th
                      onClick={() => handleSort("STATUS")}
                      style={{ cursor: "pointer" }}>
                      Status {sortConfig.key === "STATUS" && (sortConfig.direction === "asc" ? "▲" : "▼")}
                    </th>
                    <th
                      onClick={() => handleSort("NOMENCLATURE")}
                      style={{ cursor: "pointer" }}>
                      Nomenclature {sortConfig.key === "NOMENCLATURE" && (sortConfig.direction === "asc" ? "▲" : "▼")}
                    </th>
                    <th
                      onClick={() => handleSort("DIRECTOR_REMARKS")}
                      style={{ cursor: "pointer" }}>
                      Remarks {sortConfig.key === "DIRECTOR_REMARKS" && (sortConfig.direction === "asc" ? "▲" : "▼")}
                    </th>
                    {roleFilter === "responsible" && <th>Actions</th>}
                  </tr>
                </thead>
                <tbody>
                  {tableDaks.map((dak, index) => (
                    <tr key={dak.id} style={{ animationDelay: `${index * 0.1}s` }}>
                      <td className="dak-number">{dak.DAK_NO}</td>
                      {roleFilter === "responsible" && (
                        <td>{dak.RESP_OFFICER}</td>
                      )}
                      <td>
                        <span className={`status-pill status-${(dak.STATUS || "").trim().toLowerCase().replace(/\s+/g, '-')}`}>
                          {(dak.STATUS || "").trim()}
                        </span>
                      </td>
                      <td className="nomenclature">{dak.NOMENCLATURE}</td>
                      <td className="remarks">{dak.DIRECTOR_REMARKS}</td>
                      {roleFilter === "responsible" && (
                        <td>
                          {dak.STATUS &&
                          dak.STATUS.toLowerCase() === "completed" ? (
                            <button
                              className="update-btn"
                              onClick={() => handleUpdateClick(dak)}
                              title="Edit"
                            >
                              {/* Edit icon (pencil) + text */}
                              <span className="btn-text">
                                <svg style={{ marginRight: 4, verticalAlign: "middle" }} width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                  <path d="M3 17.25V21h3.75l11.02-11.02-3.75-3.75L3 17.25zM21.41 6.34c.38-.38.38-1.01 0-1.39l-2.34-2.34a.9959.9959 0 00-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.85z"/>
                                </svg>
                                Edit
                              </span>
                              <div className="btn-glow"></div>
                            </button>
                          ) : (
                            <button
                              className="update-btn"
                              onClick={() => handleUpdateClick(dak)}
                              title="Update"
                            >
                              <span className="btn-text">Update</span>
                              <div className="btn-glow"></div>
                            </button>
                          )}
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </section>
      {editingDak && (
        <div className="modal-overlay">
          <div className="modal-backdrop" onClick={handleClear}></div>
          <form id="fullscreen-update-form" onSubmit={handleSubmit} className="modal-form">
            <div className="form-header">
              <h2 className="form-title">Update DAK No: {editingDak.DAK_NO}</h2>
              <button type="button" className="close-btn" onClick={handleClear}>
                <svg viewBox="0 0 24 24" fill="currentColor">
                  <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" />
                </svg>
              </button>
            </div>
            <div className="form-grid">
              <div className="form-group">
                <label className="form-label">Letter No</label>
                <input
                  type="text"
                  name="letter_no"
                  value={form.letter_no}
                  onChange={handleFormChange}
                  className="form-input"
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Letter Date</label>
                <input
                  type="date"
                  name="letter_date"
                  value={form.letter_date}
                  onChange={handleFormChange}
                  className="form-input"
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Mode of Reply</label>
                <div className="select-wrapper">
                  <select
                    name="mode_of_reply"
                    value={form.mode_of_reply}
                    onChange={handleFormChange}
                    className="form-select"
                    required
                  >
                    <option value="">Select mode</option>
                    <option value="drona">Drona</option>
                    <option value="post">Post</option>
                    <option value="byhand">By Hand</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>
              <div className="form-group form-group-wide">
                <label className="form-label">Remarks</label>
                <textarea
                  name="remarks"
                  value={form.remarks}
                  onChange={handleFormChange}
                  className="form-textarea"
                  rows={4}
                />
              </div>
              <div className="form-group form-group-wide">
                <label className="form-label">Director's Remarks (predefined)</label>
                <input
                  type="text"
                  value={editingDak.DIRECTOR_REMARKS || ""}
                  disabled
                  readOnly
                  className="form-input readonly"
                />
              </div>
              {editingDak.DAK_ATTACHEMENT && (
                <div className="form-group attachment-group">
                  <label className="form-label">Director's Attachment</label>
                  <a
                    href={editingDak.DAK_ATTACHEMENT}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="attachment-link"
                  >
                    <svg viewBox="0 0 24 24" fill="currentColor">
                      <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z" />
                    </svg>
                    View Attachment
                  </a>
                </div>
              )}
              <div className="form-group">
                <label className="form-label">Your Attachment</label>
                <div className="file-input-wrapper">
                  <input
                    type="file"
                    name="user_attachment"
                    onChange={handleFormChange}
                    className="file-input"
                    accept="*"
                    id="file-input"
                  />
                  <label htmlFor="file-input" className="file-input-label">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                      <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z" />
                    </svg>
                    {form.user_attachment ? form.user_attachment.name : 'Choose file'}
                  </label>
                </div>
              </div>
            </div>
            <div className="form-actions">
              <button type="submit" className="submit-btn">
                <span>Submit Update</span>
                <div className="btn-shimmer"></div>
              </button>
              <button type="button" onClick={handleClear} className="cancel-btn">
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
